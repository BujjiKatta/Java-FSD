package package2;
class X {
		 public void PublicMethod(){
			 PrivateMethod();
		 }
		 public void PrivateMethod(){
			 System.out.println( "value of int in class X is"+k);
		 }

			private int k=91;
			long l=23233333l;
			protected float f=23.456f;
			public char c='k';
			
		}


