package assistedpractice;

		class Outer {
			int x=30;
			void test(){
				Inner o=new Inner();
				o.display();
			}
			class Inner{
				void display(){
					System.out.println("Value of x from outer class is : "+x);
				}
				
			}
		}
		public class innerClass
		{
			public static void main(String[] args)
			{
	
				Outer i=new Outer();
				i.test();

			}
		}


	


