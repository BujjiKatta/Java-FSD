package assistedpractice;
import java.io.File;
public class createFile {
	public static void main(String[] args) {
			// TODO Auto-generated method stub
			File myFile= new File("FileHandling");
			 myFile= new File("C:\\Users\\dell\\eclipse-workspace\\bujji\\src\\FileHandling");
			 try {
				if(myFile.createNewFile())
				{
					System.out.println("Created File Succesfully..");
				}
				else
				{
					System.out.println("File Creation error");
				}
			}
			catch (Exception e){
				System.out.println("File Error");
			}
			
		}

	}


