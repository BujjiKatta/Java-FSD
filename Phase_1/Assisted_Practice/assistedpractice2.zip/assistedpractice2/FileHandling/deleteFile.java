package assistedpractice;
import java.io.File;
public class deleteFile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
			File file=new File("C:\\Users\\dell\\eclipse-workspace\\bujji\\src\\FileHandling");

			if(file.delete())
			{
				System.out.println(file.getName()+ " is deleted");
			}
			else 
			{
				System.out.println("deletion failed");
			}
		}
		catch(Exception e){
			e.printStackTrace(); 
		}
	}
}

	


