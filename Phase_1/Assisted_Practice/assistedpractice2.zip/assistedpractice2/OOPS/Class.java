package assistedpractice;

public class Class {
	String firstname; 
    String lastname; 
    int age; 
    public Class(String firstname, String lastname, int age) 
    { 
        this.firstname = firstname; 
        this.lastname = lastname; 
        this.age = age; 
       
    } 
    public String getFirstName() 
    { 
        return firstname; 
    } 
    public String getLastName() 
    { 
        return lastname; 
    } 
    public int getAge() 
    { 
        return age; 
    } 
   
    @Override
    public String toString() 
    { 
        return("Hi my name is: "+ this.getFirstName()+" "+ this.getLastName()+".\n My age is: " + this.getAge()+"."); 
    } 
    public static void main(String[] args) 
    { 
    	Class o = new Class("Bujji","Katta", 23); 
        System.out.println(o.toString()); 
    } 
}



