package phase1;
import java.util.*;
class cameraDetails {
private int cam_id;
private String brand;
private String model;
private double price;
private boolean status;
cameraDetails(int camera_id, String brand, String model, double price, boolean Available) {
this.cam_id = camera_id;
this.brand = brand;
this.model = model;
this.price = price;
this.status = Available;
}
public int getId() {
	return cam_id;
	}
public String getBrand() {
	return brand;
	}
public String getModel() {
	return model;
	}
public double getPrice() {		
	return price;
	}	
public boolean isAvailable() {
	return status;
	}
public void setAvailable(boolean Available) {
	this.status = Available;
	}
}
public class CameraRentalApplication {
public static void main(String[] args) {
System.out.println("\t\t+------------------------------+");
System.out.println("\t\t| WELCOME TO CAMERA RENTAL APP |");
System.out.println("\t\t+------------------------------+");
String str= "=============================================================================";
double INR = 2000;
String username, password;
System.out.println("\nPLEASE LOGIN TO CONTINUE -");
Scanner sc = new Scanner(System.in);
System.out.print("USERNAME - ");
username = sc.nextLine();
System.out.print("PASSWORD - ");
password = sc.nextLine();
if (username.equals("admin") && password.equals("admin123")) {
System.out.println("\n LOGIN SUCCESSFULL ");
ArrayList<cameraDetails> list = new ArrayList<>();
list.add(new cameraDetails(1, "LG", "2130", 1500, true));
list.add(new cameraDetails(2, "Sony", "HD226", 900, true));
list.add(new cameraDetails(3, "Lenova", "5050", 1900, false));
list.add(new cameraDetails(4, "LG", "XPL", 300, true));
list.add(new cameraDetails(5, "Nikon", "SRL", 130, true));
list.add(new cameraDetails(6, "Samsung", "DS123", 250, false));
list.add(new cameraDetails(7, "Sony", "HD214", 1150, true));
list.add(new cameraDetails(8, "LG", "L123", 110, false));
list.add(new cameraDetails(9, "Samsung", "Ds123", 3300, true));
list.add(new cameraDetails(10, "Nikon", "2030", 200, true));
int m=0;
do {
int options;
Scanner o = new Scanner(System.in);
System.out.println("\n");
System.out.println("1.MY CAMERA");
System.out.println("2.RENT A CAMERA");
System.out.println("3.VIEW ALL CAMERAS");
System.out.println("4.MY WALLET");
System.out.println("5.EXIT");			
System.out.println("Select the option : ");
				options = o.nextInt();
				if(options==5) {
					System.out.println("Exit from the APP");
					break;
					}
				else {
					switch(options) {
					case 1:
						int n=0;
						do {
							int choice;
							System.out.println("1.ADD");
							System.out.println("2.REMOVE");
							System.out.println("3.VIEW MY CAMERAS");
							System.out.println("4.GO TO PREVIOUS MENU");
							System.out.println("Enter your choice : ");
							choice = sc.nextInt();
							switch(choice) {
							case 1:
								System.out.print("ENTER THE CAMERA ID - ");
								int camera_id = sc.nextInt();
								System.out.print("ENTER THE CAMERA BRAND - ");
								String brand = sc.next();
								System.out.print("ENTER THE MODEL - ");
								String model = sc.next();
								System.out.print("ENTER THE PER DAY PRICE(INR) - ");
								double price = sc.nextFloat();
								boolean Available = true;
								list.add(new cameraDetails(camera_id, brand, model, price, Available));
								System.out.println("YOUR CAMERA HAS BEEN SUCCESSFULLY ADDED TO THE LIST.");
								break;
							case 2:
								System.out.println(str);
								System.out.println("CAMERA ID\tBRAND\t\tMODEL\t\tPRICE(PERDAY)\tSTATUS");
								System.out.println(str);
								for (int i = 0; i < list.size(); i++) {
									cameraDetails cd = list.get(i);
									String status = cd.isAvailable() ? "Available" : "Rented";
									System.out.println(cd.getId() + "\t\t" + cd.getBrand() + "\t\t" + cd.getModel()
									+ "\t\t" + cd.getPrice() + "\t\t" + status);
								}
								System.out.println(str);
								int it=-1;
								System.out.print("ENTER THE CAMERA ID TO REMOVE - ");
								int cam_Id = sc.nextInt();
								for(int i = 0; i < list.size(); i++) {
									cameraDetails cd = list.get(i);
									if (cd.getId() == cam_Id) {
										it=i;
										break;
									}
								}
								if(it!=-1) {
									cameraDetails cd=list.get(it);
									if(cd.getId()==cam_Id) {
										list.remove(it);
										System.out.println("CAMERA SUCCESSFULLY REMOVED FROM THE LIST.");
										break;
									}
								}else {
									System.out.println("UNALBLE TO REMOVE");
									System.out.println("CAMERA ID "+cam_Id+" IS NOT IN THE LIST");
									break;
								}
								break;
							case 3:
								System.out.println(str);
								System.out.println("CAMERA ID\tBRAND\t\tMODEL\t\tPRICE(PER\tDAY)\tSTATUS");
								System.out.println(str);
								for (int i = 0; i < list.size(); i++) {
									cameraDetails cd = list.get(i);
									String status = cd.isAvailable() ? "Available" : "Rented";
									System.out.println(cd.getId() + "\t\t" + cd.getBrand() + "\t\t" + cd.getModel()
									+ "\t\t" + cd.getPrice() + "\t\t" + status);
								}
								System.out.println(str);
								break;
							case 4:
								m=1;
								break;
							}
							System.out.println("\nPress '0' to go to the previous menu / '1' to be in the same menu - ");
							n = sc.nextInt();
						}while(n==1);
						break;
					case 2:
						System.out.println("FOLLOWING IS THE LIST OF AVAILABLE CAMERS(S) -");
						System.out.println(str);
						System.out.println("CAMERA ID\tBRAND\t\tMODEL\t\tPRICE(PER\tDAY)\tSTATUS");
						System.out.println(str);
						for (cameraDetails cd : list) {
							if (cd.isAvailable()) {
								String status = cd.isAvailable() ? "Available" : "Rented";
								System.out.println(cd.getId() + "\t\t" + cd.getBrand() + "\t\t" + cd.getModel() + "\t\t"
										+ cd.getPrice() + "\t\t" + status);
							}
						}
						System.out.println(str);
						int x = -1;
						System.out.println("ENTER THE CAMERA ID YOU WANT TO RENT - ");
						int cam_Id = sc.nextInt();
						for (int i = 0; i < list.size(); i++) {
							cameraDetails cd = list.get(i);
							if (cd.getId() == cam_Id) {
								x = i;
								break; 
							}
						}
						if (x != -1) {
							cameraDetails cd = list.get(x);
							if (cd.getPrice() <= INR) {
								System.out.println("YOUR TRANSACTION FOR CAMERA - "+cd.getBrand()+" "+cd.getModel()+" with rent INR."+cd.getPrice()+" HAS SUCCESSFULLY COMPLETED.");
								cd.setAvailable(false);
								INR = INR - cd.getPrice();
							} else {
								System.out.println("ERROR: TRANSACTION FAILED DUE TO INSUFFICIENT WALLET BALANCE.PLEASE DEPOSIT THE AMOUNT TO YOUR WALLET.");
							}
						} else {
							System.out.println("CAMERA WITH ID " + cam_Id + " IS NOT FOUND IN THE LIST!");
						}
						break;
					case 3:
						System.out.println(str);
						System.out.println("CAMERA ID\tBRAND\t\tMODEL\t\tPRICE(PER\tDAY)\tSTATUS");
						System.out.println(str);
						for (int i = 0; i < list.size(); i++) {
							cameraDetails cd = list.get(i);
							String status = cd.isAvailable() ? "Available" : "Rented";
							System.out.println(cd.getId() + "\t\t" + cd.getBrand() + "\t\t" + cd.getModel() + "\t\t"
									+ cd.getPrice() + "\t\t" + status);
						}
						System.out.println(str);
						break;
					case 4:
						System.out.println("YOUR CURRENT WALLET BALANCE IS -" +INR);
						System.out.println("DO YOU WANT TO DEPOSITE MORE AMOUNT TO YOUR WALLET?(1.Yes 2.No)- ");
						int p = sc.nextInt();
						if (p == 1) {
							System.out.println("ENTER THE AMOUNT (INR) - ");
							double addAmount = sc.nextDouble();
							INR = INR + addAmount;
							System.out.print("YOUR WALLET BALANCE UPDATED SUCCESSFULLY.CURRENT WALLET BALANCE -"+ INR);
						}
						break;
						default:
							System.out.println("INVALID CHOICE");
							break;
					}
				}
				System.out.println("\nTO CONTINUE - PRESS (1.Yes 2.No) - ");
				m = sc.nextInt();
			}while(m==1);
		}else {
			System.out.println("INVALID LOGIN CREDENTIALS");
		}
		System.out.println("\nTHANK YOU");
	}
}
