package practiceproject;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;

import java.io.FileOutputStream;

import java.io.IOException; 

public class FileAppend {

	public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub
		 DataInputStream dis=new DataInputStream(System.in); 
		 FileOutputStream fout=new FileOutputStream("C:\\Users\\dell\\eclipse-workspace\\bujji\\src\\Files",true); 
		 BufferedOutputStream bout=new BufferedOutputStream(fout,1024);
		 System.out.println("Enter text to append to the file(@ at the end):"); 
		 char ch; 
		 while((ch=(char)dis.read())!='@') 
		 { 
            bout.write(ch); 
          
         } 
         System.out.println("Data Appended Succesfully");
           bout.close();
           }
	}
