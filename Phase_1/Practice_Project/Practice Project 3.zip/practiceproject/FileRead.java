package practiceproject;
import java.io.File;
import java.io.FileReader;
import java.util.Scanner;

public class FileRead {


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char[] array =new char[50];
		
		try{
			
			FileReader o=new FileReader("C:\\Users\\dell\\eclipse-workspace\\bujji\\src\\Files");
			
			o.read(array);
			System.out.println("Data in the given file is: ");
			System.out.println(array);
			o.close();
		}
		catch(Exception e){
			e.getStackTrace();
		}
	}

}



