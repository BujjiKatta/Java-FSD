package practiceproject;
import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;

public class FileWrite {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner k=new Scanner(System.in);
		System.out.println("Enter Data to write to a file : ");
		 String data = k.nextLine();
		
		try{
			
			FileWriter o=new FileWriter("C:\\Users\\dell\\eclipse-workspace\\bujji\\src\\d");
			
			o.write(data);
			System.out.println("Data is written successfully to file");
			o.close();
		}
		catch(Exception e){
			e.getStackTrace();
		}
	}

}
