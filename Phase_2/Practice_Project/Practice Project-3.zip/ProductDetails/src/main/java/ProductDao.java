

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
public class ProductDao {
private SessionFactory sessionFactory;
public ProductDao() {
// Initialize Hibernate configuration
Configuration configuration = new
Configuration().configure("hibernate.cfg.xml");
sessionFactory = configuration.buildSessionFactory();
}
public void saveProduct(Product product) {
Session session = sessionFactory.openSession();
Transaction transaction = null;
try {
transaction = session.beginTransaction();
// Save the product
session.save(product);
transaction.commit();
} catch (Exception e) {
if (transaction != null) {
transaction.rollback();
}
e.printStackTrace();
} finally {
session.close();
}
}
}
