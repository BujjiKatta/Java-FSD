package com.simplilearn.demo;

import java.util.Scanner;

public class Authentication{
	
	public boolean authentication(String username,String password) {
		if(username=="bujji"& password=="bujji@123") {
			return true;
		}
		else {
			return false;
		}
	}
}